/*
 * Copyright (c) Tyler Helwig
 * Helwig Development
 * www.helwigdev.com
 */

package com.helwigdev.r.simul;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Tile {
	public Tile(String type, Point location){
		this.type = type;
		this.location = location;
		try {
			image = ImageIO.read(this.getClass().getResource("/"+type+".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private String type;
	private Point location;
	private BufferedImage image;
	
	public String getType(){
		return type;
	}
	
	public String toString(){
		//System.out.println(type);
		return type;
	}
	
	public int getX(){
		return location.getX();
	}
	
	public int getY(){
		return location.getY();
	}
	
	void paint(Graphics2D g){
		g.drawImage(image, (location.getX() * 15), (location.getY() * 15), null);
	}
	

}
