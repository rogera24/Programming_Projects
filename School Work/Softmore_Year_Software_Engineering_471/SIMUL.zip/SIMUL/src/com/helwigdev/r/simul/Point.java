/*
 * Copyright (c) Tyler Helwig
 * Helwig Development
 * www.helwigdev.com
 */

package com.helwigdev.r.simul;

public class Point {
	public Point(int X, int Y, String dir) {
		this.X = X;
		this.Y = Y;
		this.dir = dir;
	}
	
	public void setDir(String dir){
		this.dir = dir;
	}

	public Point(int X, int Y) {
		this.X = X;
		this.Y = Y;
	}

	private int X;
	private int Y;
	private String dir = null;

	public int getX() {
		return X;
	}

	public int getY() {
		return Y;
	}

	public String getDir() {
		if (dir != null) {
			return dir;
		}
		return null;
	}

	public void setLocation(int X, int Y) {
		this.X = X;
		this.Y = Y;
	}
	
	public String toString(){
		return ("(" + X + "," + Y + ")");
	}
}
