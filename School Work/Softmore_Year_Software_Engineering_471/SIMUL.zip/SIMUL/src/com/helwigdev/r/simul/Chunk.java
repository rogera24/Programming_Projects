/*
 * Copyright (c) Tyler Helwig
 * Helwig Development
 * www.helwigdev.com
 */

package com.helwigdev.r.simul;

import java.util.Random;

public class Chunk {
	public Chunk(Tile[][] index, String type) {
		this.northLink = null;
		this.southLink = null;
		this.eastLink = null;
		this.westLink = null;
		this.index = index;
		this.type = type;
	}

	public Chunk(String type) {
		this.northLink = null;
		this.southLink = null;
		this.eastLink = null;
		this.westLink = null;
		this.type = type;
		this.index = populate();
		
	}

	protected Chunk northLink;
	protected Chunk southLink;
	protected Chunk eastLink;
	protected Chunk westLink;
	protected Tile[][] index;
	protected String[] types = { "Grass", "Water", "Tree", "Bush", "AppleTree",
			"BerryBush" };
	private int size = 30;
	public String type;

	protected void setLink(String direction) {
		// link = chunk we're linking to
		if (direction.equalsIgnoreCase("north")) {
			this.northLink = this;
		}
		if (direction.equalsIgnoreCase("south")) {
			this.southLink = this;
		}
		if (direction.equalsIgnoreCase("east")) {
			this.eastLink = this;
		}
		if (direction.equalsIgnoreCase("west")) {
			this.westLink = this;
		}
	}

	public Chunk getLink(String direction) {
		if (direction.equalsIgnoreCase("north")) {
			if (northLink != null) {
				return northLink;
			} else {
				Chunk c = chunkGen();
				c.setLink("south");
				return c;
			}
		}
		if (direction.equalsIgnoreCase("south")) {
			if (southLink != null) {
				return southLink;
			} else {
				Chunk c = chunkGen();
				c.setLink("north");
				return c;
			}
		}
		if (direction.equalsIgnoreCase("east")) {
			if (eastLink != null) {
				return eastLink;
			} else {
				Chunk c = chunkGen();
				c.setLink("west");
				return c;
			}
		}
		if (direction.equalsIgnoreCase("west")) {
			if (westLink != null) {
				return westLink;
			} else {
				Chunk c = chunkGen();
				c.setLink("east");
				return c;
			}
		}
		System.out.println("Error getting next chunk");
		return this;
	}

	private Chunk chunkGen() {
		// each chunk is 30x30
		Tile[][] gen = populate();
		return new Chunk(gen, type);
	}

	private Tile[][] populate() {
		Tile[][] gen = new Tile[size][size];
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				Random random = new Random();

				if (type.equalsIgnoreCase("Grassy")) {

					if (random.nextDouble() < 0.2) {
						gen[i][j] = new Tile("grass", new Point(i, j));
					} else {
						gen[i][j] = new Tile(
								types[new Random().nextInt(types.length)],
								new Point(i, j));
					}

				} else if (type.equalsIgnoreCase("Watery")) {

					if (random.nextDouble() < 0.16) {
						gen[i][j] = new Tile("water", new Point(i, j));
					} else {
						gen[i][j] = new Tile(
								types[new Random().nextInt(types.length)],
								new Point(i, j));
					}

				} else if (type.equalsIgnoreCase("Forest")) {

					double r = random.nextDouble();
					if (r < 0.08) {
						gen[i][j] = new Tile("tree", new Point(i, j));
					} else if (r < 0.16) {
						gen[i][j] = new Tile("appletree", new Point(i, j));
					} else {
						gen[i][j] = new Tile(
								types[new Random().nextInt(types.length)],
								new Point(i, j));
					}

				} else {

					gen[i][j] = new Tile(
							types[new Random().nextInt(types.length)],
							new Point(i, j));
					System.out
							.println("No world type found!");

				}
			}
		}
		return gen;
	}

	public Chunk chunkInit() {
		return chunkGen();
	}

	public int getSize() {
		return size;
	}

	public Tile getTile(int x, int y) {
		return index[x][y];
	}

	public String toString() {
		for (int i = 0; i < index.length; i++) {
			for (int j = 0; j < index.length; j++) {
				System.out.println("" + index[i][j]);
			}
		}
		System.out.println("!!!!!DONE!!!!!");
		return "!!!!!DONE!!!!!";
	}

}
