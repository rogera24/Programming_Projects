/*
 * Copyright (c) Tyler Helwig
 * Helwig Development
 * www.helwigdev.com
 */

package com.helwigdev.r.simul;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class World {
	WorldFrame frame;

	private static Chunk c;
	int i = 0;
	private ArrayList<Animal> animals;

	public World(String type) {
		c = new Chunk(type);
		animals = new ArrayList<Animal>();
		Object[] possibilities = { 1, 2, 3, 4, 5 };
		int numAnimals = (int) JOptionPane.showInputDialog(new JFrame(),
				"Choose number of animals:", "Customized Dialog",
				JOptionPane.PLAIN_MESSAGE, null, possibilities, "anchor");
		for (int i = 0; i < numAnimals; i++) {
			animals.add(new Animal(this.getInitialChunk(), new Point(15, 15)));
		}
		frame = new WorldFrame(c, animals);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);

		Timer timer = new Timer(1000, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				tick();
			}
		});
		timer.setRepeats(true);
		timer.setCoalesce(false);
		timer.start();
		System.out.println("World initialized");
	}

	private void tick() {
		System.out.println("Fire tick " + i + ":");
		i++;
		for (Animal animal : animals) {
			System.out.println("\t" + animal.tick());
			System.out.println("\t Death = " + animal.death);

		}
		frame.setChunk(animals.get(0).getChunk());
		frame.repaint();

	}

	public static Chunk getInitialChunk() {
		return c;
	}
}
