/*
 * Copyright (c) Tyler Helwig
 * Helwig Development
 * www.helwigdev.com
 */

package com.helwigdev.r.simul;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class WorldFrame extends JFrame {
	Chunk currentChunk;
	WorldComponent wc;
	public WorldFrame(Chunk c, ArrayList<Animal> animals) {
		currentChunk = c;
		wc = new WorldComponent(c, animals);
		this.setVisible(true);
		this.add(wc, BorderLayout.CENTER);
		JPanel panel = new JPanel();
		
//
//		JButton south = new JButton("Move south");
//		south.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// TODO Auto-generated method stub
//				currentChunk = currentChunk.getLink("south");
//				updateFrame(currentChunk);
//			}
//		});
//		JButton north = new JButton("Move north");
//		north.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// TODO Auto-generated method stub
//				currentChunk = currentChunk.getLink("north");
//				updateFrame(currentChunk);
//			}
//		});
//		JButton west = new JButton("Move west");
//		west.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent arg0) {
//				// TODO Auto-generated method stub
//				currentChunk = currentChunk.getLink("west");
//				updateFrame(currentChunk);
//			}
//		});
//		JButton east = new JButton("Move east");
//		east.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// TODO Auto-generated method stub
//				currentChunk = currentChunk.getLink("east");
//				updateFrame(currentChunk);
//			}
//		});
//		
//		GridLayout gl = new GridLayout(1, 4);
//		
//		panel.setLayout(gl);
//		panel.add(west, gl);
//		panel.add(south, gl);
//		panel.add(north, gl);
//		panel.add(east, gl);
//		
//		this.add(panel, BorderLayout.SOUTH);
		this.pack();
		this.setVisible(true);
	}
	
	public void setChunk(Chunk c){
		wc.setChunk(c);
	}
	
//	public void updateFrame(Chunk c){
//		this.remove(wc);
//		wc = new WorldComponent(c);
//		this.add(wc, BorderLayout.CENTER);
//		this.revalidate();
//		this.repaint();
//		
//	}
}
