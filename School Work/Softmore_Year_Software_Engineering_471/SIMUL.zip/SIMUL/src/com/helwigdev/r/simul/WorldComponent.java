/*
 * Copyright (c) Tyler Helwig
 * Helwig Development
 * www.helwigdev.com
 */

package com.helwigdev.r.simul;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;

import javax.swing.JComponent;

public class WorldComponent extends JComponent {
	ArrayList<Tile> tiles;
	ArrayList<Animal> animals;
	Chunk currentChunk;

	public WorldComponent(Chunk c, ArrayList<Animal> animals) {
		this.currentChunk = c;
		tiles = new ArrayList<Tile>();
		for (int i = 0; i < c.getSize(); i++) {
			for (int j = 0; j < c.getSize(); j++) {
				tiles.add(c.getTile(i, j));
			}
		}
		this.animals = animals;

	}
	
	public void setChunk(Chunk c){
		currentChunk = c;
	}

	public WorldComponent(Chunk c) {
		this.currentChunk = c;
		tiles = new ArrayList<Tile>();
		for (int i = 0; i < c.getSize(); i++) {
			for (int j = 0; j < c.getSize(); j++) {
				tiles.add(c.getTile(i, j));
			}
		}
		this.animals = new ArrayList<Animal>();

	}

	

	@Override
	protected void paintComponent(Graphics arg0) {
		// TODO Auto-generated method stub
		super.paintComponent(arg0);

		Graphics2D g = (Graphics2D) arg0;
		for (Tile tile : tiles) {
			tile.paint(g);
		}
		for (Animal animal : animals) {
			//if (animal.death == false) {
				animal.paint(g);

			//}
		}
		this.revalidate();
		this.repaint();
	}

}
