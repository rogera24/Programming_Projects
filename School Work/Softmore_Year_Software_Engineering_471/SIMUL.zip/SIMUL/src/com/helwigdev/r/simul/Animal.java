package com.helwigdev.r.simul;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.Stack;

import javax.imageio.ImageIO;

public class Animal {
	boolean sets = false;
	boolean pathed = false;
	public boolean death = false;
	private double health;
	private double hunger;
	private double thirst;
	private double sleep;
	private double energy;
	private String move;
	private Tile[][] View; // 13x13x1
	private String perform;
	private Point gps;
	private Chunk MyChunk; // 30x30x1
	private BufferedImage image;

	public Animal(Chunk chunk, Point point) {
		this.health = 1.0;
		this.hunger = 1.0;
		this.thirst = 1.0;
		this.sleep = 1.0;
		this.energy = 1.0;
		this.gps = point;
		this.MyChunk = chunk;
		this.gps.setDir("north");
		try {
			image = ImageIO.read(getClass().getResource("/Animal.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean getDeath() {
		return death;
	}

	public Chunk getChunk() {
		return MyChunk;
	}

	public void currentgoal() {
		if (perform == null) {
			if (this.hunger >= .75 && this.thirst >= .75) {
				if (sleep <= 0) {
					setPriority("Sleep");
				} else {
					setPriority("Explore");
				}
			} else {
				if (this.hunger >= .75 && this.thirst <= .75) {
					setPriority("Thirst");
				}
				if (this.hunger <= .75 && this.thirst >= .75) {
					setPriority("Hunger");
				} else {
					if ((this.thirst / 7.0) > this.hunger) {
						setPriority("Hunger");
					} else {
						setPriority("Thirst");
					}
				}
			}
		} else {
			setPriority(perform);
		}
	}

	private void setPriority(String s) {
		if (s.equalsIgnoreCase("hunger")) {
			eat();
		}
		if (s.equalsIgnoreCase("thirst")) {
			drink();
		}
		if (s.equalsIgnoreCase("sleep")) {
			sleep();
		}
		if (s.equalsIgnoreCase("explore")) {
			explore();
		}
	}

	private void eat() {
		int x = -1;
		int y = -1;
		int d = 0;
		boolean ate = false;
		for (int i = 0; i < 10; i++) {
			if (MyChunk.getTile(gps.getX() + x, gps.getY() + y).getType()
					.equals("apple")) {
				this.hunger = (this.hunger + .10);
				this.rendir(d, "hunger");
				ate = true;
				System.out.println("I ate!");
				break;
			} else if (MyChunk.getTile(gps.getX() + x, gps.getY() + y)
					.getType().equals("berry")) {
				this.hunger = (this.hunger + .10);
				this.rendir(d, "hunger");
				ate = true;
				System.out.println("I ate!");
				break;
			} else {
				d++;
				if (y != 1) {
					y++;
				} else {
					if (x != 1) {
						y = -1;
						x++;
					}
				}
			}
		}
		if (ate == false) {
			explore();
		}
	}

	private void drink() {
		int x = -1;
		int y = -1;
		int d = 0;
		boolean drank = false;
		for (int i = 0; i < 10; i++) {
			if (MyChunk.getTile(gps.getX() + x, gps.getY() + y).getType()
					.equals("water")) {
				this.thirst = (this.thirst + .10);
				this.rendir(d, "thirst");
				drank = true;
				System.out.println("I drank!");
				break;
			} else {
				d++;
				if (y != 1) {
					y++;
				} else {
					if (x != 1) {
						y = -1;
						x++;
					}
				}
			}
		}
		if (drank == false) {
			explore();
		}
	}

	private void sleep() {
		sleep = (sleep + 0.006);
		System.out.println("I slept!");
		this.rendir(0, "sleep");
	}

	private void explore() {
		Random random = new Random();
		int num = random.nextInt(4);
		if (num == 0) {
			if (MyChunk.getTile(gps.getX(), gps.getY() - 1).getType()
					.equalsIgnoreCase("water")) {
				explore(1, 0);
			} else {
				System.out.println("I moved!");
				gps.setLocation(gps.getX(), gps.getY() - 1);
			}
		}
		if (num == 1) {
			if (MyChunk.getTile(gps.getX() + 1, gps.getY()).getType()
					.equalsIgnoreCase("water")) {
				explore(2, 0);
			} else {
				System.out.println("I moved!");
				gps.setLocation(gps.getX() + 1, gps.getY());
			}
		}
		if (num == 2) {
			if (MyChunk.getTile(gps.getX(), gps.getY() + 1).getType()
					.equalsIgnoreCase("water")) {
				explore(3, 0);
			} else {
				System.out.println("I moved!");
				gps.setLocation(gps.getX(), gps.getY() + 1);
			}
		}
		if (num == 3) {
			if (MyChunk.getTile(gps.getX() - 1, gps.getY()).getType()
					.equalsIgnoreCase("water")) {
				explore(0, 0);
			} else {
				System.out.println("I moved!");
				gps.setLocation(gps.getX() - 1, gps.getY());
			}
		}
	}

	private void explore(int i, int j) {
		if (j == 4) {
			this.death = true;
		} else {
			j++;
			if (i == 0) {
				if (MyChunk.getTile(gps.getX(), gps.getY() - 1).getType()
						.equalsIgnoreCase("water")) {
					explore(1, j);
				} else {
					System.out.println("I moved!");
					gps.setLocation(gps.getX(), gps.getY() - 1);
				}
			}
			if (i == 1) {
				if (MyChunk.getTile(gps.getX() + 1, gps.getY()).getType()
						.equalsIgnoreCase("water")) {
					explore(2, j);
				} else {
					System.out.println("I moved!");
					gps.setLocation(gps.getX() + 1, gps.getY());
				}
			}
			if (i == 2) {
				if (MyChunk.getTile(gps.getX(), gps.getY() + 1).getType()
						.equalsIgnoreCase("water")) {
					explore(3, j);
				} else {
					System.out.println("I moved!");
					gps.setLocation(gps.getX(), gps.getY() + 1);
				}
			}
			if (i == 3) {
				if (MyChunk.getTile(gps.getX() - 1, gps.getY()).getType()
						.equalsIgnoreCase("water")) {
					explore(0, j);
				} else {
					System.out.println("I moved!");
					gps.setLocation(gps.getX() - 1, gps.getY());
				}
			}
		}
	}

	private void rendir(int c, String string) {
		if (c == 0 || c == 1) {
			gps.setDir("north");
		}
		if (c == 2 || c == 4) {
			gps.setDir("east");
		}
		if (c == 7 || c == 8) {
			gps.setDir("south");
		}
		if (c == 3 || c == 6) {
			gps.setDir("west");
		}
		if (this.thirst >= 1) {
			this.perform = null;
		} else {
			this.perform = string;
		}
	}

	public Point tick() {
		if (death == false) {
			// this.setView();
			this.status_inc();
			this.currentgoal();
		}
		return gps;
	}

	private Tile[][] setView() {
		Chunk temp = null;
		int x = 0;
		int y = 0;
		Tile[][] tempChunk = new Tile[13][13];
		for (int a = 0; a < 13; a++) {
			for (int b = 0; b < 13; b++) {
				// Top
				// Left------------------------------------------------------------------------------------
				if (gps.getX() - (6 + a) < 0 && gps.getY() - (6 + a) < 0) {
					temp = MyChunk.getLink("north");
					temp.getLink("west");
					x = 29 + (gps.getX() - (6 + a));
					y = 29 + (gps.getY() - (6 + a));
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Top
				// Mid-------------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) > 0 && gps.getX() - (6 + a) < 30
						&& gps.getY() - (6 + b) < 0) {
					temp = MyChunk.getLink("east");
					x = (gps.getX() - (6 + a));
					y = 29 - (gps.getY() - (6 + a));
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Top
				// Right------------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) > 30 && gps.getY() - (6 + b) > 0) {
					temp = MyChunk.getLink("north");
					temp.getLink("east");
					x = (gps.getX() - (6 + a)) - 30;
					y = 29 + (gps.getY() - (6 + a));
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Left
				// Mid-------------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) < 0 && gps.getY() - (6 + a) < 30
						&& gps.getY() - (6 + b) > 0) {
					temp = MyChunk.getLink("west");
					x = 29 + (gps.getX() - (6 + a));
					y = (gps.getY() - (6 + a));
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Right
				// Mid------------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) > 30 && gps.getY() - (6 + b) < 30
						&& gps.getY() - (6 + b) > 0) {
					temp = MyChunk.getLink("east");
					x = (gps.getX() - (6 + a)) - 29;
					y = (gps.getY() - (6 + a));
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Bottom
				// Left----------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) < 0 && gps.getY() - (6 + b) > 30) {
					temp = MyChunk.getLink("south");
					temp.getLink("west");
					x = 29 + (gps.getX() - (6 + a));
					y = (gps.getY() - (6 + a)) - 29;
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Bottom
				// Mid-----------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) > 0 && gps.getX() - (6 + a) < 30
						&& gps.getY() - (6 + b) > 30) {
					temp = MyChunk.getLink("south");
					x = (gps.getX() - (6 + a));
					y = (gps.getY() - (6 + a)) - 29;
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Bottom
				// Right---------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) > 30 && gps.getY() - (6 + b) > 30) {
					temp = MyChunk.getLink("south");
					temp.getLink("east");
					x = (gps.getX() - (6 + a)) - 29;
					y = (gps.getY() - (6 + a)) - 29;
					tempChunk[a][b] = temp.getTile(x, y);
				}
				// Middle---------------------------------------------------------------------------------------
				else if (gps.getX() - (6 + a) < 30 && gps.getY() - (6 + b) < 30
						&& gps.getX() - (6 + a) > 0 && gps.getY() - (6 + b) > 0) {
					temp = MyChunk;
					x = (gps.getX() - (6 + a));
					y = (gps.getY() - (6 + a));
					tempChunk[a][b] = temp.getTile(x, y);
				}
			}
		}
		System.out.println("View Set");
		return View = tempChunk;
	}

	private void status_inc() {
		this.thirst = (this.thirst - .000667); // From full Thirst = 3 days time
		this.hunger = (this.hunger - .000032); // From full Hunger = 3 weeks
												// time
		this.sleep = (this.sleep - .003); /* From full Sleep = 16 hours time */
		this.health = ((this.hunger + this.thirst + this.sleep) / 2);
		if (this.health <= 0) {
			System.out.println("I died XP");
			death = true;
		}
	}

	class TileNode {
		TileNode(Tile t) {
			tile = t;
			prev = null;
		}

		Tile tile;
		TileNode prev;
	}

	/*
	 * void findPath(Tile src, Tile dest){ Set<Tile> set = new HashSet<Tile>();
	 * ArrayList<TileNode> front = new ArrayList<TileNode>(); front.add(new
	 * TileNode(src)); //add the source to the front //Breadth first search
	 * TileNode destNode = null; while(front.isEmpty()==false &&
	 * destNode==null){ ArrayList<TileNode> front2 = new ArrayList<TileNode>();
	 * for(int i=0; i<front.size(); ++i){ TileNode t = front.get(i); if(t.tile
	 * == dest){ destNode = t; break; } sets = set.add(t.tile.north); if(sets ==
	 * true){front2.add(new TileNode(t.tile.north, t));} sets =
	 * set.add(t.tile.east); if(sets == true){front2.add(new
	 * TileNode(t.tile.east, t));} sets = set.add(t.tile.south); if(sets ==
	 * true){front2.add(new TileNode(t.tile.south, t));} sets =
	 * set.add(t.tile.west); if(sets == true){front2.add(new
	 * TileNode(t.tile.west, t));} } front = front2; } Stack<Tile> path = new
	 * Stack<Tile>(); if(destNode != null) {//found the destination. TileNode t
	 * = destNode; while(t != null){ path.push(t.tile); System.out.print(t); t =
	 * t.prev; } } }
	 */

	public void paint(Graphics2D g) {
		if (death == false) {
			g.drawImage(image, (gps.getX() * 15), (gps.getY() * 15), null);
		}
	}

}
