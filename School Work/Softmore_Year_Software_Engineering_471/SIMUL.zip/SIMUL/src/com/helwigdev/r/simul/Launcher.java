/*
 * Copyright (c) Tyler Helwig
 * Helwig Development
 * www.helwigdev.com
 */

package com.helwigdev.r.simul;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Launcher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Make the data gathering window
		Object[] possibilities = {"Watery","Grassy","Forest"};
		String s = (String) JOptionPane.showInputDialog(new JFrame(),
				"Choose the world type:",
				"Customized Dialog", JOptionPane.PLAIN_MESSAGE, null,
				possibilities, "anchor");
		if(s == null){
			s = "grassy";
			System.out.println("Using default Grassy");
		}
		System.out.println(s);
		World world = new World(s);
		
	}

}
